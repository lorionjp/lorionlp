<?php
App::uses('AppController', 'Controller');

class AdminsController extends AppController {

    public $name = 'Admins';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Playmember',
            'User'
            );

    public $layout = 'default';

    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('login', 'register');
    }

    public function login() {
        // フォームに入力があった場合のみログイン処理を行い、ダッシュボードへ移動
        if ($this->request->is('post')) {
            // debug($this->request->data);
            if ($this->Auth->login()) {
                    $this->redirect($this->Auth->redirectUrl());
            } else {
                $this->Flash->set(__('ユーザ名またはパスワードが誤っています。再度入力してください。'));
            }
        }
    }

    public function register() {
        if($this->request->is('post') && $this->User->save($this->request->data)) {
            $this->Auth->login();
            $this->redirect('login');
        }
    }

    public function logout() {
        $this->Auth->logout();
        $this->Session->destroy();
        $this->redirect(array('controller'=>'admins', 'action'=>'login'));
    }

    public function index() {
    }

    public function players() {
        $this->set('Player', $this->Player->find('all', array('order' => array('Player.id desc'))));
    }

    public function gameDelete($id=null) {
        $this->Game->id=$id;
        if($this->Game->delete()) {
            $this->Flash->set('削除完了');
            $this->redirect(array('action'=>'allgames'));
        } else {
            $this->Flash->set('削除失敗');
        }
    }

    public function player_result() {
        $game_id = $this->Session->read('game_id');
        $this->set('Player_score', $this->Player_score->find('all', array('conditions'=>array('game_id'=>$game_id), 'order' => array('Player_score.playmember_id asc'))));
        $this->set('Player', $this->Player->find('all', array('conditions'=>array('game_id'=>$game_id), 'order' => array('Player_score.playmember_id asc'))));

    }


    public function score() {
        $game_id = $this->Session->read('game_id');

        $this->set('game', $this->Game->find('first',array('conditions'=>array('game_id'=>$game_id))));

        if($this->request->is('post')) {
            $frontR = $this->request->data['Score']['front1'];
            $frontR += $this->request->data['Score']['front2'];
            $frontR += $this->request->data['Score']['front3'];
            $frontR += $this->request->data['Score']['front4'];
            $frontR += $this->request->data['Score']['front5'];
            $frontR += $this->request->data['Score']['front6'];
            $frontR += $this->request->data['Score']['front7'];
            $this->request->data['Score'] += array('frontR' => $frontR);
            $backR = $this->request->data['Score']['back1'];
            $backR += $this->request->data['Score']['back2'];
            $backR += $this->request->data['Score']['back3'];
            $backR += $this->request->data['Score']['back4'];
            $backR += $this->request->data['Score']['back5'];
            $backR += $this->request->data['Score']['back6'];
            $backR += $this->request->data['Score']['back7'];
            $this->request->data['Score'] += array('backR' => $backR);
            $this->request->data['Score'] += array('game_id' => $game_id);
            $this->Score->save($this->request->data);

            $this->redirect('playmember');

        }

    }

    public function add_game() {
        $game_id = date('mdHi');
        if($this->request->is('post')) {
            $this->request->data['Game'] += array('game_id' => $game_id);
            if($this->Game->save($this->request->data)) {
                $this->Session->write('game_id',$this->request->data['Game']['game_id']);
                $this->redirect('score');
            } else {
                $this->Flash->set('入力失敗');
            }
        }
    }

    public function edit_game() {
        $game = $this->Game->find('all', array('order' => array('Game.date desc')));
        $this->set('Game', $game);
    }

    public function edit_game_result($game_id = null) {
        // $this->Game->id=$id;
        $this->Game->game_id=$game_id;
        // $this->Player_score->id=$id;
        if($this->request->is('get')) {
            // $gameDate=$this->Game->read();
        $gamedata = array();
        $gamedata += $this->Game->find('first',array('conditions'=>array('game_id'=>$game_id)));
        $gamedata += $this->Score->find('first',array('conditions'=>array('game_id'=>$game_id)));

        $playmember = $this->Playmember->find('all',array('conditions'=>array('game_id'=>$game_id),'fields'=>array('position', 'uniformNumber')));
        $playerName = $this->Player->find('all');

        $attack_num = $gamedata['Game']['attack_num'];

        $all_player_score = array();

            for($i=0;$i<count($playmember);$i++){
                $player_id = $playmember[$i]['Playmember']['uniformNumber'];
                $player_value = $this->Player_score->find('all',array('conditions'=>array('game_id'=>$game_id, 'playmember_id'=>$player_id),'fields'=>array('value')));
                $player_name = array($i=>$this->Player->find('first',array('conditions'=>array('uniformNumber'=>$player_id),'fields'=>'playerName')));
                $playmember[$i]['Playmember'] += array('player_name' => $player_name[$i]['Player']['playerName']);
                $playmember[$i]['Playmember'] += array('batting_num' => $i + 1);
                $playmember[$i]['Playmember'] += array('player_value' => $player_value);

                $player_position = $playmember[$i]['Playmember']['position'];

                if($player_position == 1) {
                    $position_text = '投';
                } else if ($player_position == 2) {
                    $position_text = '捕';
                } else if ($player_position == 3) {
                    $position_text = '一';
                } else if ($player_position == 4) {
                    $position_text = '二';
                } else if ($player_position == 5) {
                    $position_text = '三';
                } else if ($player_position == 6) {
                    $position_text = '遊';
                } else if ($player_position == 7) {
                    $position_text = '左';
                } else if ($player_position == 8) {
                    $position_text = '中';
                } else if ($player_position == 9) {
                    $position_text = '右';
                } else {
                    $position_text = 'DH';
                }

                $playmember[$i]['Playmember'] += array('position_text' => $position_text);

            }

        if ($attack_num == 1) {
            $front_team = 'RIZIN';
            $opponent = $gamedata['Game']['opponent'];
            $back_team = mb_substr($opponent, 0, 2);
        } else if ($attack_num == 2) {
            $opponent = $gamedata['Game']['opponent'];
            $front_team = mb_substr($opponent, 0, 2);
            $back_team = 'RIZIN';
        }

        $this->set("gamedata", $gamedata);
        $this->set("front_team", $front_team);
        $this->set("back_team", $back_team);
        $this->set("Playmember", $playmember);

        if($this->request->is('get')) {
            $this->request->data=$this->Game->read();
        } else {
            if($this->Game->save($this->request->data)) {
                $this->Flash->set('更新完了');
                $this->redirect(array('action' => 'edit_game'));
            } else {
                $this->Flash->set('更新失敗');
            }
        }
    }

}

    public function add_member() {
        if($this->request->is('post')) {
            if($this->Player->save($this->request->data)) {
                $this->Flash->set('入力完了');
                $this->redirect(array('action' => 'edit_member'));
            } else {
                $this->Flash->set('入力失敗');
            }
        }
    }

    public function edit_member() {
        $this->set('Player', $this->Player->find('all', array('order' => array('Player.uniformNumber asc'))));
    }

    public function edit_player($id = null) {
        $this->Player->id=$id;
        if($this->request->is('get')) {
            $this->request->data=$this->Player->read();
        } else {
            if($this->Player->save($this->request->data)) {
                $this->Flash->set('更新完了');
                $this->redirect(array('action' => 'edit_member'));
            } else {
                $this->Flash->set('更新失敗');
            }
        }
    }

    public function delete_member($id=null) {

        $this->Player->id=$id;
        if($this->Player->delete()) //データの削除、addと同じ
        {
            $this->Flash->set('削除完了');
            $this->redirect(array('action'=>'/edit_member'));
        }
        else
        {
            $this->Flash->set('削除失敗');
        }
    }

    public function edit($id = null) {
        $this->Player_score->id=$id;

        if ($this->request->is('get')) {
            $this->request->data=$this->Player_score->read();
        } else {

            if ($this->Player_score->save($this->request->data)) {
                $this->Flash->set('更新完了');
                $this->redirect(array('action'=>'/index'));
            } else {
                $this->Flash->set('更新失敗');
            }
        }
    }
}











