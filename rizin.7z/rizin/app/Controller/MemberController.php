<?php

App::uses('AppController', 'Controller');

class MemberController extends AppController {

    public $name = 'Member';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Game',
            'Playmember',
            'Conference',
            'User'
           );

    public $layout = 'default';
    public $components = array('Auth', 'Session');
 
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow();
        $this->set('auth', $this->Auth);
    }
 
    public function admin_add() {
        if($this->request->is('post')) {
            if($this->Player->save($this->request->data)) {
                $this->Flash->set('入力完了');
                $this->redirect(array('action' => 'edit_member'));
            } else {
                $this->Flash->set('入力失敗');
            }
        }
    }

    public function admin_edit() {
        $this->set('Player', $this->Player->find('all', array('order' => array('Player.uniformNumber asc'))));
    }



}

