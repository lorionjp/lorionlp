<?php
App::uses('AppController', 'Controller');

class AdminsController extends AppController {

    public $name = 'Admins';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Playmember',
            'User'
            );

    public $layout = 'default';

    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('login', 'register');
    }

    public function login() {
        // フォームに入力があった場合のみログイン処理を行い、ダッシュボードへ移動
        if ($this->request->is('post')) {
            // debug($this->request->data);
            if ($this->Auth->login()) {
                    $this->redirect($this->Auth->redirectUrl());
            } else {
                $this->Flash->set(__('ユーザ名またはパスワードが誤っています。再度入力してください。'));
            }
        }
    }

    public function register() {
        if($this->request->is('post') && $this->User->save($this->request->data)) {
            $this->Auth->login();
            $this->redirect('login');
        }
    }

    public function logout() {
        $this->Auth->logout();
        $this->Session->destroy();
        $this->redirect(array('controller'=>'admins', 'action'=>'login'));
    }

    public function players() {
        $this->set('Player', $this->Player->find('all', array('order' => array('Player.id desc'))));
    }

    public function player_result() {
        $game_id = $this->Session->read('game_id');
        $this->set('Player_score', $this->Player_score->find('all', array('conditions'=>array('game_id'=>$game_id), 'order' => array('Player_score.playmember_id asc'))));
        $this->set('Player', $this->Player->find('all', array('conditions'=>array('game_id'=>$game_id), 'order' => array('Player_score.playmember_id asc'))));

    }


    public function player_point() {

    }

    public function playerResult() {

    }

    public function score() {
        $game_id = $this->Session->read('game_id');

        $this->set('game', $this->Game->find('first',array('conditions'=>array('game_id'=>$game_id))));

        if($this->request->is('post')) {
            $frontR = $this->request->data['Score']['front1'];
            $frontR += $this->request->data['Score']['front2'];
            $frontR += $this->request->data['Score']['front3'];
            $frontR += $this->request->data['Score']['front4'];
            $frontR += $this->request->data['Score']['front5'];
            $frontR += $this->request->data['Score']['front6'];
            $frontR += $this->request->data['Score']['front7'];
            $this->request->data['Score'] += array('frontR' => $frontR);
            $backR = $this->request->data['Score']['back1'];
            $backR += $this->request->data['Score']['back2'];
            $backR += $this->request->data['Score']['back3'];
            $backR += $this->request->data['Score']['back4'];
            $backR += $this->request->data['Score']['back5'];
            $backR += $this->request->data['Score']['back6'];
            $backR += $this->request->data['Score']['back7'];
            $this->request->data['Score'] += array('backR' => $backR);
            $this->request->data['Score'] += array('game_id' => $game_id);
            $this->Score->save($this->request->data);

            $this->redirect('playmember');

        }

    }

    public function edit_player($id = null) {
        $this->Player->id=$id;
        if($this->request->is('get')) {
            $this->request->data=$this->Player->read();
        } else {
            if($this->Player->save($this->request->data)) {
                $this->Flash->set('更新完了');
                $this->redirect(array('action' => 'edit_member'));
            } else {
                $this->Flash->set('更新失敗');
            }
        }
    }

    public function delete_member($id=null) {

        $this->Player->id=$id;
        if($this->Player->delete()) //データの削除、addと同じ
        {
            $this->Flash->set('削除完了');
            $this->redirect(array('action'=>'/edit_member'));
        }
        else
        {
            $this->Flash->set('削除失敗');
        }
    }

    public function edit($id = null) {
        $this->Player_score->id=$id;

        if ($this->request->is('get')) {
            $this->request->data=$this->Player_score->read();
        } else {

            if ($this->Player_score->save($this->request->data)) {
                $this->Flash->set('更新完了');
                $this->redirect(array('action'=>'/index'));
            } else {
                $this->Flash->set('更新失敗');
            }
        }
    }
}











