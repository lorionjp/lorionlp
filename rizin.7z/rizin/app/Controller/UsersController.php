<?php

App::uses('AppController', 'Controller');

class UsersController extends AppController {

    public $name = 'Users';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Game',
            'Playmember',
            'Conference',
            'User'
           );

    public $layout = 'default';
    public $components = array('Auth', 'Session');
 
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow();
        $this->set('auth', $this->Auth);
    }
 
    public function index() {
    }

    public function admin_index() {
    }

    public function conference() {
        $this->set('Conference', $this->Conference->find('all', array('order' => array('Conference.id desc'))));
    }

}

