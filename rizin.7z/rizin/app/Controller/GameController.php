<?php

App::uses('AppController', 'Controller');

class GameController extends AppController {

    public $name = 'Game';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Game',
            'Playmember',
            'Conference',
            'User'
           );

    public $layout = 'default';
    public $components = array('Auth', 'Session');
 
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow();
        $this->set('auth', $this->Auth);
    }
 
    public function index() {
        $this->set('Game', $this->Game->find('all', array('order' => array('Game.date desc'))));
    }

    public function detail($game_id = null) {
        // $this->Game->id=$id;
        $this->Game->game_id=$game_id;
        // $this->Player_score->id=$id;
        if($this->request->is('get')) {
            // $gameDate=$this->Game->read();
        $gamedata = array();
        $gamedata += $this->Game->find('first',array('conditions'=>array('game_id'=>$game_id)));
        $gamedata += $this->Score->find('first',array('conditions'=>array('game_id'=>$game_id)));

        $playmember = $this->Playmember->find('all',array('conditions'=>array('game_id'=>$game_id),'fields'=>array('position', 'uniformNumber')));
        $playerName = $this->Player->find('all');

        $attack_num = $gamedata['Game']['attack_num'];

        $all_player_score = array();
            for($i=0;$i<count($playmember);$i++){
                $player_id = $playmember[$i]['Playmember']['uniformNumber'];
                $player_value = $this->Player_score->find('all',array('conditions'=>array('game_id'=>$game_id, 'playmember_id'=>$player_id),'fields'=>array('value')));
                $player_name = array($i=>$this->Player->find('first',array('conditions'=>array('uniformNumber'=>$player_id),'fields'=>'playerName')));
                $playmember[$i]['Playmember'] += array('player_name' => $player_name[$i]['Player']['playerName']);
                $playmember[$i]['Playmember'] += array('batting_num' => $i + 1);
                $playmember[$i]['Playmember'] += array('player_value' => $player_value);

                $player_position = $playmember[$i]['Playmember']['position'];

                if($player_position == 1) {
                    $position_text = '投';
                } else if ($player_position == 2) {
                    $position_text = '捕';
                } else if ($player_position == 3) {
                    $position_text = '一';
                } else if ($player_position == 4) {
                    $position_text = '二';
                } else if ($player_position == 5) {
                    $position_text = '三';
                } else if ($player_position == 6) {
                    $position_text = '遊';
                } else if ($player_position == 7) {
                    $position_text = '左';
                } else if ($player_position == 8) {
                    $position_text = '中';
                } else if ($player_position == 9) {
                    $position_text = '右';
                } else {
                    $position_text = 'DH';
                }

                $playmember[$i]['Playmember'] += array('position_text' => $position_text);

            }

        if ($attack_num == 1) {
            $front_team = 'RIZIN';
            $opponent = $gamedata['Game']['opponent'];
            $back_team = mb_substr($opponent, 0, 2);
        } else if ($attack_num == 2) {
            $opponent = $gamedata['Game']['opponent'];
            $front_team = mb_substr($opponent, 0, 2);
            $back_team = 'RIZIN';
        }

        $this->set("gamedata", $gamedata);
        $this->set("front_team", $front_team);
        $this->set("back_team", $back_team);
        $this->set("Playmember", $playmember);

            // $Player_scoreDate=$this->Player_score->read();
        } else {
            if($this->Player->save($this->request->data)) {
                $this->Flash->set('更新完了');
                $this->redirect(array('action' => 'members'));
            } else {
                $this->Flash->set('更新失敗');
            }
        }
    }

// 管理画面

    public function admin_add() {
        $game_id = date('mdHi');
        if($this->request->is('post')) {
            $this->request->data['Game'] += array('game_id' => $game_id);
            if($this->Game->save($this->request->data)) {
                $this->Session->write('game_id',$this->request->data['Game']['game_id']);
                $this->redirect('score');
            } else {
                $this->Flash->set('入力失敗');
            }
        }
    }

    public function edit_game() {
        $game = $this->Game->find('all', array('order' => array('Game.date desc')));
        $this->set('Game', $game);
    }

    public function admin_result($game_id = null) {
        // $this->Game->id=$id;
        $this->Game->game_id=$game_id;
        // $this->Player_score->id=$id;
        if($this->request->is('get')) {
            // $gameDate=$this->Game->read();
        $gamedata = array();
        $gamedata += $this->Game->find('first',array('conditions'=>array('game_id'=>$game_id)));
        $gamedata += $this->Score->find('first',array('conditions'=>array('game_id'=>$game_id)));

        $playmember = $this->Playmember->find('all',array('conditions'=>array('game_id'=>$game_id),'fields'=>array('position', 'uniformNumber')));
        $playerName = $this->Player->find('all');

        $attack_num = $gamedata['Game']['attack_num'];

        $all_player_score = array();

            for($i=0;$i<count($playmember);$i++){
                $player_id = $playmember[$i]['Playmember']['uniformNumber'];
                $player_value = $this->Player_score->find('all',array('conditions'=>array('game_id'=>$game_id, 'playmember_id'=>$player_id),'fields'=>array('value')));
                $player_name = array($i=>$this->Player->find('first',array('conditions'=>array('uniformNumber'=>$player_id),'fields'=>'playerName')));
                $playmember[$i]['Playmember'] += array('player_name' => $player_name[$i]['Player']['playerName']);
                $playmember[$i]['Playmember'] += array('batting_num' => $i + 1);
                $playmember[$i]['Playmember'] += array('player_value' => $player_value);

                $player_position = $playmember[$i]['Playmember']['position'];

                if($player_position == 1) {
                    $position_text = '投';
                } else if ($player_position == 2) {
                    $position_text = '捕';
                } else if ($player_position == 3) {
                    $position_text = '一';
                } else if ($player_position == 4) {
                    $position_text = '二';
                } else if ($player_position == 5) {
                    $position_text = '三';
                } else if ($player_position == 6) {
                    $position_text = '遊';
                } else if ($player_position == 7) {
                    $position_text = '左';
                } else if ($player_position == 8) {
                    $position_text = '中';
                } else if ($player_position == 9) {
                    $position_text = '右';
                } else {
                    $position_text = 'DH';
                }

                $playmember[$i]['Playmember'] += array('position_text' => $position_text);

            }

        if ($attack_num == 1) {
            $front_team = 'RIZIN';
            $opponent = $gamedata['Game']['opponent'];
            $back_team = mb_substr($opponent, 0, 2);
        } else if ($attack_num == 2) {
            $opponent = $gamedata['Game']['opponent'];
            $front_team = mb_substr($opponent, 0, 2);
            $back_team = 'RIZIN';
        }

        $this->set("gamedata", $gamedata);
        $this->set("front_team", $front_team);
        $this->set("back_team", $back_team);
        $this->set("Playmember", $playmember);

        if($this->request->is('get')) {
            $this->request->data=$this->Game->read();
        } else {
                if($this->Game->save($this->request->data)) {
                    $this->Flash->set('更新完了');
                    $this->redirect(array('action' => 'edit_game'));
                } else {
                    $this->Flash->set('更新失敗');
                }
            }
        }
    }
}

