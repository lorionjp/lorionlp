<?php

App::uses('AppController', 'Controller');

class ScoreController extends AppController {

    public $name = 'Score';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Game',
            'Playmember',
            'Conference',
            'User'
           );

    public $layout = 'default';
    public $components = array('Auth', 'Session');
 
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow();
        $this->set('auth', $this->Auth);
    }
 
    public function index() {
        $play_member = $this->Player->find('all', array('order' => array('Player.uniformNumber asc')));
        $play_score = $this->Player_score->find('all');
        $play_point = $this->Player_point->find('all');

        for($i = 0; $i < count($play_member); $i++){

            $player_num = $play_member[$i]['Player']['uniformNumber'];
// 試合数
            $game_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                ),
            );
// 打席数
            $bat_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type >' => 0,
                ),
            );
// 打数
            $value_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(1,2,3,4,11,12,13,31),
                ),
            );
// 得点
            $run_count = $this->Player_point->find('all', array(
                'fields' => array('sum(run_point) as sum_run_point'),
                'conditions' => array(
                    'playmember_id' => $player_num,
                ), 
            ));
// 安打数
             $hit1_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(1,2,3,4),
                ),
            );
// 二塁打
             $hit2_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(2),
                ),
            );
// 三塁打
             $hit3_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(3),
                ),
            );
// 本塁打
             $hit4_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(4),
                ),
            );
// 打点
            $hit_point_count = $this->Player_score->find('all', array(
                'fields' => array('sum(hit_point) as sum_hit_point'),
                'conditions' => array(
                    'playmember_id' => $player_num,
                ), 
            ));
// 盗塁
            $steal_count = $this->Player_point->find('all', array(
                'fields' => array('sum(steal) as sum_steal'),
                'conditions' => array(
                    'playmember_id' => $player_num,
                ), 
            ));
// 犠打飛
             $sacrifice_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(23),
                ),
            );
// 四球
             $walk_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(21),
                ),
            );
// 死球
             $deadball_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(22),
                ),
            );
// 三振
             $strikeout_count = array(
                'conditions' => array(
                    'playmember_id' => $player_num,
                    'hit_type' => array(13),
                ),
            );
           
            $player_run_count = $run_count[0][0];
            $player_hit_point_count = $hit_point_count[0][0];
            $player_steal_count = $steal_count[0][0];

            $player_game_count = $this->Player_point->find('count', $game_count);
            $player_bat_count = $this->Player_score->find('count', $bat_count);
            $player_value_count = $this->Player_score->find('count', $value_count);
            $player_hit1_count = $this->Player_score->find('count', $hit1_count);
            $player_hit2_count = $this->Player_score->find('count', $hit2_count);
            $player_hit3_count = $this->Player_score->find('count', $hit3_count);
            $player_hit4_count = $this->Player_score->find('count', $hit4_count);
            $player_sacrifice_count = $this->Player_score->find('count', $sacrifice_count);
            $player_walk_count = $this->Player_score->find('count', $walk_count);
            $player_deadball_count = $this->Player_score->find('count', $deadball_count);
            $player_strikeout_count = $this->Player_score->find('count', $strikeout_count);
            // $batting_average = 
            $onbase = $player_hit1_count + $player_walk_count + $player_deadball_count;
            $int_sum_hit = intval($player_hit1_count);
            $int_onbase = intval($onbase);
            $int_bat_count = intval($player_bat_count);

            if($player_bat_count == 0) {
            } else {
                $player_bat_count2 = $player_bat_count - $player_sacrifice_count;
            }
            $int_bat_count2 = intval($player_bat_count2);
            $int_value_count = intval($player_value_count);

            if ($int_value_count == 0) {
                $player_average = '0.00';
            } else {
                $player_average = $int_sum_hit / $int_value_count;
            }

            if ($int_bat_count == 0) {
                $player_onbase = '0.00';
            } else {
                $player_onbase = $int_onbase / $int_bat_count2;
            }

            $player_average_sprintf = sprintf('%.3f',$player_average);
            $player_onbase_sprintf = sprintf('%.3f',$player_onbase);


            $play_member[$i]['Player'] += array('player_game_count' => $player_game_count);
            $play_member[$i]['Player'] += array('player_bat_count' => $player_bat_count);
            $play_member[$i]['Player'] += array('player_value_count' => $player_value_count);
            $play_member[$i]['Player'] += array('player_average_sprintf' => $player_average_sprintf);
            $play_member[$i]['Player'] += array('player_onbase_sprintf' => $player_onbase_sprintf);
            $play_member[$i]['Player'] += array('player_value_count' => $player_value_count);
            $play_member[$i]['Player'] += array('player_run_count' => $player_run_count);
            $play_member[$i]['Player'] += array('player_hit1_count' => $player_hit1_count);
            $play_member[$i]['Player'] += array('player_hit2_count' => $player_hit2_count);
            $play_member[$i]['Player'] += array('player_hit3_count' => $player_hit3_count);
            $play_member[$i]['Player'] += array('player_hit4_count' => $player_hit4_count);
            $play_member[$i]['Player'] += array('player_hit4_count' => $player_hit4_count);
            $play_member[$i]['Player'] += array('player_hit_point_count' => $player_hit_point_count);
            $play_member[$i]['Player'] += array('player_steal_count' => $player_steal_count);
            $play_member[$i]['Player'] += array('player_sacrifice_count' => $player_sacrifice_count);
            $play_member[$i]['Player'] += array('player_walk_count' => $player_walk_count);
            $play_member[$i]['Player'] += array('player_deadball_count' => $player_deadball_count);
            $play_member[$i]['Player'] += array('player_strikeout_count' => $player_strikeout_count);

        }

        $this->set('Playmember', $play_member);
        $this->set('Player_score', $this->Player_score->find('all'));
        $this->set('Player_point', $this->Player_point->find('all'));
        // $this->set('Player_point', $this->Player_point->find('all'));
    }
}

