<?php

App::uses('AppController', 'Controller');

class InputGamesController extends AppController {

    public $name = 'InputGames';
    public $uses = array(
            'Player_score',
            'Player_point',
            'Position',
            'Result',
            'Score',
            'Player',
            'Game',
            'Playmember',
            'Conference',
            'User'
           );

    public $layout = 'default';
    public $components = array('Auth', 'Session');
 
    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow();
        $this->set('auth', $this->Auth);
    }
 
    public function admin_detail() {
        $game_id = date('mdHi');
        if($this->request->is('post')) {
            $this->request->data['Game'] += array('game_id' => $game_id);
            $this->Session->write('game_data',$this->request->data['Game']);
            debug($this->Session->read('game_data'));
            $this->redirect('score');
        }
    }

    public function admin_score() {
        $game_data = $this->Session->read('game_data');
        if($this->request->is('post')) {
            $this->Session->write('score_data',$this->request->data['Score']);
            $this->redirect('member');
        }
        debug($this->Session->read('game_data'));
        debug($this->Session->read('score_data'));
        $this->set('game_data', $game_data);
    }

    public function admin_member() {
        $game_data = $this->Session->read('game_data');
        if($this->request->is('post')) {
            $this->Session->write('score_data',$this->request->data['Score']);
        }
            debug($this->Session->read('game_data'));
        debug($this->Session->read('score_data'));
        $this->set('game_data', $game_data);
    }


}

