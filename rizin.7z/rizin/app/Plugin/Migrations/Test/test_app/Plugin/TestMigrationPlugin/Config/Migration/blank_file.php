<?php
// Blank file for testing loading a migration file without a class matching it
