<?php
class Game extends AppModel {
    public $name = "game";

    public $validate = array(
        'game_id' => array(
            array(
                'rule' => 'isUnique',
                'message' => 'IDが重複しています。',
            ),
        ),
        'date' => array(
            array(
                'rule' => 'isUnique',
                'message' => 'IDが重複しています。',
            ),
        ),
        // 'type' => array(
        //     array(
        //         'rule' => 'notBlank',
        //         'message' => '選択してください',
        //     ),
        // ),
        // 'location' => array(
        //     array(
        //         'rule' => 'notBlank',
        //         'message' => '場所を入力してください',
        //     ),
        // ),
        // 'membersNum' => array(
        //     array(
        //         'rule' => 'numeric',
        //         'message' => '数字で入力してください',
        //     ),
        //     array(
        //         'rule' => 'notBlank',
        //         'message' => '出場人数を入力してください',
        //     ),
        // ),
        // 'opponent' => array(
        //     array(
        //         'rule' => 'notBlank',
        //         'message' => '場所を入力してください',
        //     ),
        // ),
    );
}