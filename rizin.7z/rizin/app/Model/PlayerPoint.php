<?php
class Player_point extends AppModel {
    public $hasMany = 'Player_score'
}