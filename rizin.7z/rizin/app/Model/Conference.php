<?php
class Conference extends AppModel {
    public $name = "conference";
}