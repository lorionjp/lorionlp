<?php
class Score extends AppModel {
    public $name = "score";
}