<?php

App::uses('AppController', 'Controller');

class UsersController extends AppController {

	public $name = 'Users';

	public $uses = array(
		);

	public $layout = 'default';

	public function beforeFilter() {

	}

	public function index() {
		
	}
}

?>