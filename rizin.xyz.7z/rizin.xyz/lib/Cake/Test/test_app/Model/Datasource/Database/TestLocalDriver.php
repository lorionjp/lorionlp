<?php

App::uses('TestSource', 'TestPlugin.Model/Datasource');

class TestLocalDriver extends TestSource {
}
