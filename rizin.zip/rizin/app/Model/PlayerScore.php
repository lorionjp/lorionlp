<?php
class Player_score extends AppModel {
    public $name = "Player_score";
}