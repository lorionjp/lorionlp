<?php
class Playmember extends AppModel {
    public $name = "Playmember";

    // public $hasOne = "Player";
}