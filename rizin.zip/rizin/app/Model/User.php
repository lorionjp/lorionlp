<?php
App::uses('AppModel', 'Model');

class User extends AppModel {

    public $name = "Users";

    public $validate = array(
        'username' => array(
            array(
            'rule' => 'isUnique', //重複禁止
            'message' => '既に使用されている名前です。'
            ),
            array(
                'rule' => 'alphaNumeric',
                'message' => '名前は半角英数字にしてください'
            ),
            array(
                'rule' => array('between',2,32),
                'message' => '名前は2文字以上32文字以内にしてください'
            )
        ),
        'password' => array(
            array(
                'rule' => 'alphaNumeric',
                'message' => 'パスワードは半角英数字にしてください'
            ),
            array(
                'rule' => array('between',4,32),
                'message' => 'パスワードは4文字以上32文字以内にしてください'
            )
        )
    );

    public function beforeSave($options = array()) {
        $this->data['User']['password'] = AuthComponent::password($this->data['User']['password']);
        return true;
    }

    // var $name = 'User';
    // var $useTable = 'users';

    // public $validate = array(
    //     'username' => array(
    //         array(
    //             'rule' => 'notEmpty', 
    //             'message' => 'メールアドレスを入力してください'
    //         ), 
    //         array(
    //             'rule' => 'email', 
    //             'message' => '正しいメールアドレスを入力してください'
    //         ), 
    //         array(
    //             'rule' => 'isUnique', 
    //             'message' => '入力されたメールアドレスは既に登録されています'
    //         ), 
    //     ),
    //     'password' => array(
    //         array(
    //             'rule' => 'notEmpty', 
    //             'message' => 'パスワードを入力してください'
    //         ), 
    //         array(
    //             'rule' => 'alphanumericsymbols', 
    //             'message' => 'パスワードに使用できない文字が入力されています'
    //         ), 
    //         array(
    //             'rule' => array('minLength', 8), 
    //             'message' => 'パスワードは8文字以上入力してください', 
    //         ),
    //         array(
    //             'rule' => 'passwordConfirm', 
    //             'message' => 'パスワードが一致していません'
    //         ), 
    //     ),
    //     'password_confirm' => array(
    //         array(
    //             'rule' => 'notEmpty', 
    //             'message' => 'パスワード(確認)を入力してください'
    //         ), 
    //     ),
    // );

    // public function beforeSave($options = array()) {

    //     if (isset($this->data[$this->alias]['password'])) {
    //         $passwordHasher = new BlowfishPasswordHasher();
    //         $this->data[$this->alias]['password'] = $passwordHasher->hash(
    //             $this->data[$this->alias]['password']
    //         );
    //     }

    //     return true;

    // }

    // public function passwordConfirm($check){

    //     //２つのパスワードフィールドが一致する事を確認する
    //     if($this->data['User']['password'] === $this->data['User']['password_confirm']){
    //         return true;
    //     }else{
    //         return false;
    //     }

    // }

    // public function alphanumericsymbols($check){
    //     $value = array_values($check);
    //     $value = $value[0];
    //     return preg_match('/^[a-zA-Z0-9\s\x21-\x2f\x3a-\x40\x5b-\x60\x7b-\x7e]+$/', $value);
    // }

}