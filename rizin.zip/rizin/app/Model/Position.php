<?php
class Position extends AppModel {
    public $name = "position";
}