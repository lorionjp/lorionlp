<?php
class Player extends AppModel {
    public $name = "player";

    public $validate = array(
        'uniformNumber' => array(
            array(
                'rule' => 'isUnique',
                'message' => 'このユーザー名はすでに登録されています',
            ),
            array(
                'rule' => 'notBlank',
                'message' => '背番号の入力',
            ),
            array(
                'rule' => 'numeric',
                'message' => '数字で入力してください',
                )
        ),
        'playerName' => array(
            array(
                'rule' => 'notBlank',
                'message' => '名前の入力',
            )
        ),
    );
}