<?php
class PostsController extends AppController {
    public $helpers = array('Html', 'Form');
}