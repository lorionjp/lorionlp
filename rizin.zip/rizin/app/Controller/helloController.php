<?php
class HelloController extends AppController {
    public function index() {

    }
}