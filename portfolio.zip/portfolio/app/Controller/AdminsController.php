<?php

App::uses('AppController', 'Controller');

class AdminsController extends AppController {

	public $name = 'Admins';

	public $uses = array(
		);

	public $layout = 'admin';

	public function beforeFilter() {

	}

    public function index() {
        
    }

    public function widgets() {
        
    }
}

?>